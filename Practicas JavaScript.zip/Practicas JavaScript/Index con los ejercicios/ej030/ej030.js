// Only change code below this line
const myName = "Jose Antonio";
const myStr = "My name is " + myName + " and I anm well!";