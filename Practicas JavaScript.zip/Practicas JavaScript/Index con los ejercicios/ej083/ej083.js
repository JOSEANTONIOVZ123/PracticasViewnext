const myDog = {
  // Only change code below this line
name:"Paquito",
legs:4,
tails:1,
friends:["Pablo","Zizou"]
  // Only change code above this line
};