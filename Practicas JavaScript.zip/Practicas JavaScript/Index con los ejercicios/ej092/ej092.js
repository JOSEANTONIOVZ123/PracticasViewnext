const myMusic = [
  {
    "artist": "Billy Joel",
    "title": "Piano Man",
    "release_year": 1973,
    "formats": [
      "CD",
      "8T",
      "LP"
    ],
    "gold": true,
  },
  
  {
    "artist": "Toby Fox",
    "title": "Megalovabia",
    "release_year": 2012,
    "formats": [
      "CD",
      "8T"
    ],

  }
];