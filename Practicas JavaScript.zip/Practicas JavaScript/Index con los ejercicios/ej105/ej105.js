function randomFraction() {

  // Only change code below this line
  let result=0;
result= Math.random();
  return result;

  // Only change code above this line
}