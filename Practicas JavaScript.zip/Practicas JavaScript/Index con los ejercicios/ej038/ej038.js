const myNoun = "dog";
const myAdjective = "big";
const myVerb = "ran";
const myAdverb = "quickly";

// Only change code below this line
const wordBlanks = "I see a " + myNoun + " and a " + myAdjective + " Bee so we " + myVerb + " so " + myAdverb + " it was terrifying."; // Change this line
// Only change code above this line