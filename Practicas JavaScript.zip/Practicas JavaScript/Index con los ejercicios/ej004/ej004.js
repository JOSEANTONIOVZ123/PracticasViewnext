// Setup
var a;
a = 7;
var b;

// Only change code below this line

b=a;