const myArray = [50, 60, 70];
console.log(myArray[0]);
const myData=myArray[0]
