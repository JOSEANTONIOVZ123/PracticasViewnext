let catName = "Oliver";
let catSound = "Meow!";

