function convertToInteger(str) {
return parseInt(str);
}

convertToInteger("56");