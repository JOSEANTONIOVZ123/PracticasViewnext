let a = 3;
let b = 17;
let c = 12;

// Only change code below this line
a += 12;
b += 9 ;
c += 7;