// Setup
const myArray = [];

// Only change code below this line

for(let i=9;i>=1;i-=2){
  myArray.push(i);
}