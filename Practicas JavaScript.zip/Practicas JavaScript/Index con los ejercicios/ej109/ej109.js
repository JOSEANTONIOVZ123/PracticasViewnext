function convertToInteger(str) {
  return parseInt(str, 2);
}

convertToInteger("10011");