let myVar = 11;

// Only change code below this line
myVar--;