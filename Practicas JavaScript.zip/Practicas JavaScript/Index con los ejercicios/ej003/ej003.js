// Setup
var a;

// Only change code below this line
a=7;
