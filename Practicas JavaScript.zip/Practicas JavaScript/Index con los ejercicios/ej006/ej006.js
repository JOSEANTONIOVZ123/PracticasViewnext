var myFirstName;
var myLastName;
myFirstName="Jose";
myLastName="Zafra";