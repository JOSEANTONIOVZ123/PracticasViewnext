// Change code below this line
const someAdjective = "wonderful";
let myStr = "Learning to code is ";
myStr += someAdjective;