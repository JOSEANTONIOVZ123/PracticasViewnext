// Setup
function phoneticLookup(val) {
  let result = "";

  // Only change code below this line
  result="";
   var lookup = {
    "alpha":"Adams",
    "bravo":"Boston",
    "charlie":"Chicago",
    "delta":"Denver",
    "echo":"Easy",
    "foxtrot":"Frank"
  };

  // Only change code above this line
  return lookup[val];
return result;
}

phoneticLookup("charlie");