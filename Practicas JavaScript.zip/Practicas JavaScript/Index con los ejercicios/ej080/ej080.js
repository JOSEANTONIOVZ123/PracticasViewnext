function isLess(a, b) {
  // Only change code below this line
 return a <= b;
  // Only change code above this line
}

isLess(10, 15);