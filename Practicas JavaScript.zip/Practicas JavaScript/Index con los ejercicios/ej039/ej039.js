// Only change code below this line
const myArray = ["Mango",7];