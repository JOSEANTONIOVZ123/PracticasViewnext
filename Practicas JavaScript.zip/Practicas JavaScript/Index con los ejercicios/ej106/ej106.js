var randomWholeNumber = Math.floor(Math.random()*20);
function randomWholeNum() {
  return Math.floor(Math.random()*10);
}