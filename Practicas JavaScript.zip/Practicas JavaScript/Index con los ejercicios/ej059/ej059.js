function trueOrFalse(wasThatTrue) {
  // Only change code below this line
if(wasThatTrue){
  return "Yes, that was true";
} else return "No, that was false";


  // Only change code above this line

}
console.log(trueOrFalse(false));