//This is an in-line comment
/*This is a multi-line comment */