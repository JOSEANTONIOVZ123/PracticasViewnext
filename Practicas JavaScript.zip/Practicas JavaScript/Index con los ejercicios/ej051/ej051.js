function timesFive(num){
  return num*5;
}
console.log(timesFive(5));