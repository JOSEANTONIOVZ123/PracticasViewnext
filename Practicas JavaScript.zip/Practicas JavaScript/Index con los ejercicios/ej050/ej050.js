function functionWithArgs(param1,param2){
  console.log(param1 + param2);
}

functionWithArgs(1,2);
functionWithArgs(7,9);