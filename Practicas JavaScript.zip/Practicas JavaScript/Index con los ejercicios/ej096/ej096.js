// Setup
const myArray = [];

// Only change code below this line
let i =5;

while(i>=0){
  myArray.push(i);
  i--;
}