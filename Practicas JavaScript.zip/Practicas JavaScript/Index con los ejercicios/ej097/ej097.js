// Setup
const myArray = [];

// Only change code below this line


for(let i=1;i<=5; i++){
  myArray.push(i);
}