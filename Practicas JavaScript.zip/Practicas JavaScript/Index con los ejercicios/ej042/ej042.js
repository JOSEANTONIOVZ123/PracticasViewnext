// Setup
const myArray = [18, 64, 99];

// Only change code below this line
myArray[0] = 45;