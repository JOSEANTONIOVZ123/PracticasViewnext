let respuesta = document.getElementById("Pelis");
let respuesta2 = document.getElementById("Pelis2");
let respuesta3 = document.getElementById("Pelis3");

function mostrar(genero) {
    let edad = document.getElementById("Edad").value;
    respuesta.innerHTML="";
    respuesta2.innerHTML="";
    respuesta3.innerHTML="";
    switch(genero){
        case 'Comedia':
            if(edad>13 && edad<=16){
                respuesta.innerHTML=("- Back to the Future - ATP");
                respuesta2.innerHTML="- The Truman Show - +13";
                
            }else if (edad>16) {
               respuesta.innerHTML=("- Back to the Future - ATP ");
               respuesta2.innerHTML="- The Truman Show - +13";
               respuesta3.innerHTML="- The Wolf of Wall Street - +16";
            }else{
                respuesta.innerHTML=("- Back to the Future - ATP");
            }
         break;
         case 'Crimen':
            if(edad>13 && edad <=16){
               respuesta.innerHTML=(" - El secreto de sus ojos - +13");
                
            }else if (edad>16) {
               respuesta.innerHTML=("- El secreto de sus ojos - +13");
               respuesta2.innerHTML=" - The Godfather - +16";
            }else{
                respuesta.innerHTML=("- No hay peliculas ATP");
            }
            break;
        case 'Drama':
            if(edad>13 && edad<=16){
                respuesta.innerHTML=(" - Casablanca - ATP");
                respuesta2.innerHTML="- The Shawshank Redemption - +13";
                
            }else if (edad>16) {
               respuesta.innerHTML=(" - Casablanca - ATP");
               respuesta2.innerHTML="- The Shawshank Redemption - +13";
               respuesta3.innerHTML="- Taxi Driver - +16";
            }else{
                respuesta.innerHTML=(" - Casablanca - ATP");
            }
            break;
        case 'Musical':
            if(edad>13 && edad<=16){
                respuesta.innerHTML=(" - La La Land - ATP");
                respuesta2.innerHTML="- Les Miserables - +13";
                
            }else if (edad>16) {
               respuesta.innerHTML=(" - La La Land - ATP");
               respuesta2.innerHTML="- Les Miserables - +13";
               respuesta3.innerHTML="- The Rocky Horror Picture Show - +16";
            }else{
                respuesta.innerHTML=(" - La La Land - ATP");
            }
            break;
         default:
         alert("nada");
    }

}