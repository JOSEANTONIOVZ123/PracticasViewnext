let notas = [6, 9, 7, 5, 1, 5, 4, 3];
let media =0;
function promedio() {
    for( let x=0; x<=notas.length; x++){
     media = Number(media) + Number(notas[x]);   
    };
    let promedio = media/notas.length
    return promedio;
}
console.log(promedio());