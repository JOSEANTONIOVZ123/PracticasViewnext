let operador= document.getElementById("opera")
function multiplicar(){
    for (let x = 0; x < 10; x++) {
        let mul= operador.value*x;
        document.write("<p>"+operador.value+" * "+ x +" = "+mul+"</p>")
        
    }
}