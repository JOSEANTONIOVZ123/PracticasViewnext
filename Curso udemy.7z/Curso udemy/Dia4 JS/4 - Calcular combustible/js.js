function calcularLitros(){
    let elementoKm = document.getElementById("textoKm");
    let textoKm = elementoKm.value;
    let cantKm = Number(textoKm);

    let cantLitros = cantKm / 8.8;

    let resultado = document.getElementById("textoResultado");
    resultado.textContent = "Carga " + Math.ceil(cantLitros) + " Litros de combustible"
}