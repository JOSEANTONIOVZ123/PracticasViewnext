let resp= document.getElementById("respuesta");


function suma(){
    let num1 = document.getElementById("num1");
    let num2 = document.getElementById("num2");
    let suma= +num1.value + +num2.value;
    resp.innerHTML=suma;

}


function resta(){
    let num1 = document.getElementById("num1");
    let num2 = document.getElementById("num2");
    let resta= +num1.value - +num2.value;
    resp.innerHTML=resta


}



function mul(){
    let num1 = document.getElementById("num1");
    let num2 = document.getElementById("num2");
    let mul= +num1.value * +num2.value;
    resp.innerHTML=mul;

}

function div(){
    let num1 = document.getElementById("num1");
    let num2 = document.getElementById("num2");
    let div= +num1.value / +num2.value;
    resp.innerHTML=div
}

function potencia(){
    let num1 = document.getElementById("num1");
    let num2 = document.getElementById("num2");
    let potencia= Math.pow(+num1.value , +num2.value);
    resp.innerHTML=potencia

}

function raiz(){
    let num1 = document.getElementById("num1");
    let num2 = document.getElementById("num2");
    let raiz= Math.sqrt(+num1.value , +num2.value);
    resp.innerHTML=raiz

}



function rand(){
    let num1 = document.getElementById("num1");
    let num2 = document.getElementById("num2");
    let rand= Math.abs(~((Math.random()*(num1.value - num2.value))+num2.value));
    resp.innerHTML=rand
    
    
}

function abs(){
    console.log("La respuesta es : "+resp.textContent);
    let abs= Math.abs(resp.innerText);
    console.log(abs)
    resp.innerText=abs
}