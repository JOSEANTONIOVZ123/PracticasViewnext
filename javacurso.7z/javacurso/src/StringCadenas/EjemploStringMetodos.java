package StringCadenas;

public class EjemploStringMetodos {
    public static void main(String[] args) {
        String nombre = "Jose";
        System.out.println("nombre.length() = " + nombre.length());
        System.out.println("nombre.toUpperCase() = " + nombre.toUpperCase());
        System.out.println("nombre.toLowerCase() = " + nombre.toLowerCase());
        System.out.println("nombre.equals(\"Jose\") = " + nombre.equals("Jose"));
        System.out.println("nombre.compareTo(\"Jose\") = " + nombre.equals("jose"));
        System.out.println("nombre.compareToIgnoreCase(\"jose\") = " + nombre.compareToIgnoreCase("jose"));
        System.out.println("nombre.compareTo(\"Jose\") = " + nombre.compareTo("Jose"));
        System.out.println("nombre.compareTo(\"Aron\") = " + nombre.compareTo("Aron"));
        System.out.println("nombre.charAt(\"0\") = " + nombre.charAt(0));
        System.out.println("nombre.charAt(\"0\") = " + nombre.charAt(1));
        System.out.println("nombre.charAt(\"0\") = " + nombre.charAt(2));
        System.out.println("nombre.charAt(\"0\") = " + nombre.charAt(3));
        System.out.println("nombre.charAt(nombre.length()-1) = " + nombre.charAt(nombre.length()-1));
        System.out.println("nombre.substring(1) = " + nombre.substring(1));
        System.out.println("nombre.substring(1, 2) = " + nombre.substring(0, 3));
        System.out.println("nombre.substring(nombre.length()-1) = " + nombre.substring(nombre.length()-1));
        String trabaLenguas = "trabalenguas";
        System.out.println("trabaLenguas.replace(\"a\",\".\") = " + trabaLenguas.replace("a","."));
        System.out.println("trabaLenguas = " + trabaLenguas);
        System.out.println("trabaLenguas.indexOf('a') = " + trabaLenguas.indexOf('a'));
        System.out.println("trabaLenguas.lastIndexOf('a') = " + trabaLenguas.lastIndexOf('a'));
        System.out.println("trabaLenguas.lastIndexOf(\"t\") = " + trabaLenguas.lastIndexOf("t"));
        System.out.println("trabaLenguas.contains(\"lenguas\") = " + trabaLenguas.contains("lenguas"));
        System.out.println("trabaLenguas.startsWith(\"traba\") = " + trabaLenguas.startsWith("traba"));
        System.out.println("trabaLenguas.endsWith(\"lenguas\") = " + trabaLenguas.endsWith("lenguas"));
        System.out.println("  trabalenguas  ");
        System.out.println("  trabalenguas  ".trim());






    }
}
