package StringCadenas;

import java.util.Scanner;

public class ProgramaManejoDeNombres {
    public static void main(String[] args) {

        Scanner scanner= new Scanner(System.in);

        System.out.println("Ingrese el nombre de tu madre");
        String nombre1= scanner.nextLine();
        System.out.println("Ingrese el nombre de tu padre");
        String nombre2= scanner.nextLine();
        System.out.println("Ingrese el nombre de tu hermano/a");
        String nombre3= scanner.nextLine();
        String letra1= nombre1.substring(1 , 2).toUpperCase();
        String letra2= nombre2.substring(1,2).toUpperCase();
        String letra3= nombre3.substring(1,2).toUpperCase();
        String letra1Final= nombre1.substring(nombre1.length()-2 );
        String letra2Final= nombre2.substring(nombre2.length()-2);
        String letra3Final= nombre3.substring(nombre3.length()-2 );
        String total1=(letra1.concat(".".concat(letra1Final)));
        String total2=(letra2.concat(".".concat(letra2Final)));
        String total3=(letra3.concat(".".concat(letra3Final)));
        System.out.print(total1.concat("_"));
        System.out.print(total2.concat("_"));
        System.out.print(total3);


    }
}
