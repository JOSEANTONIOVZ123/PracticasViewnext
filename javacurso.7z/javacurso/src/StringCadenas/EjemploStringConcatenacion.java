package StringCadenas;

public class EjemploStringConcatenacion {
    public static void main(String[] args) {
        String curso= "Programacion Java";
        String profesor = "Andrés Guzmán";

        String detalle = curso+ " con el instructor " + profesor+ " ";
        System.out.println(detalle);

        int numeroA=10;
        int numeroB=5;
        System.out.println(detalle+(numeroA+numeroB));
        System.out.println(numeroA+numeroB+detalle);

        String numeroC = Integer.toString(numeroA);
        String numeroD = Integer.toString(numeroB);

        String detalle2 = curso.concat(" con ".concat(profesor).concat(numeroC).concat(numeroD));
        System.out.println("detalle2: "+detalle2);

    }
}
