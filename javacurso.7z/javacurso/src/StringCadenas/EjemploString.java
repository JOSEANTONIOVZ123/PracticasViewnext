package StringCadenas;

public class EjemploString {
    public static void main(String[] args) {
        String curso= "Programacion Java";
        String curso2= new String("Programacion Java");
        System.out.println(curso);
        System.out.println(curso2);

        boolean esIgual = curso.equalsIgnoreCase(curso2);
        System.out.println("urso.equalsIgnoreCase(curso2) = " + esIgual);

        esIgual=curso==curso2;
        System.out.println("curso==curso2 = " + esIgual);

        String curso3 = "Programacion Java";
        esIgual = curso == curso3;
        System.out.println("curso == curso3 = " + esIgual);


    }
}
