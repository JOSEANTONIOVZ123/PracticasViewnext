package Operadores;

import java.util.Scanner;

public class OperadoresLogicosLogin {
    public static void main(String[] args) {

        /*String[] usernames = new String[3];
        usernames[0] = "Jose";
        usernames[1] = "Andres";
        usernames[2] = "pepe";
        String[] passwords = new String[3];
        passwords[0] = "123456";
        passwords[1] = "123456";
        passwords[2] = "123456";*/

        String[] usernames = {"andres","admin", "jose"};
        String[] passwords = {"123","1234","12345"};

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el username");

        String user = scanner.nextLine();
        System.out.println("Ingrese el password");
        String pass = scanner.nextLine();

        boolean esAutenticado = false;

        for (int i = 0; i < usernames.length; i++) {
            esAutenticado = (usernames[i].equals(user) && passwords[i].equals(pass))? true:esAutenticado;

        }
            String mensaje = esAutenticado ? "bienvenido usuario".concat(user).concat("!"):
                    "Username o contraseña incorrecto!\nLo sentimos, requiere autenticacion";
        System.out.println(mensaje);

            /*if (usernames[i].equals(user) && passwords[i].equals(pass)) {
                System.out.print("Bienvenido ");
                esAutenticado = true;
                i = usernames.length;

            }else{
                System.out.println("Usuario o contraseña incorrecta");

            }
        }
             */

    }
}
