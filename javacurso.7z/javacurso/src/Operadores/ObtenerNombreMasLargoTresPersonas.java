package Operadores;

import javax.swing.*;


public class ObtenerNombreMasLargoTresPersonas {
    public static void main(String[] args) {
        String nombre = "";
        String nombre1 = JOptionPane.showInputDialog("Imprime el primer nombre y apellido");
        String nombre2 =  JOptionPane.showInputDialog("Imprime el segundo nombre y apellido");
        String nombre3 = JOptionPane.showInputDialog("Imprime el tercer nombre y apellido");

        String maximo = (nombre1.split(" ")[0].length()
                < nombre2.split(" ")[0].length()) ? nombre2 : nombre1;
        maximo = (nombre3.split(" ")[0].length()
                < maximo.split(" ")[0].length()) ? maximo : nombre3;

        System.out.println(" La persona con el nombre mas largo es ".concat(maximo));
    }
}
