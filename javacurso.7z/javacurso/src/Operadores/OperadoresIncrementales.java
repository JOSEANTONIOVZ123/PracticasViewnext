package Operadores;

public class OperadoresIncrementales {
    public static void main(String[] args) {
        //preincremento
        int i = 1;
        int j = ++i;
        System.out.println("j = " + j);
        System.out.println("i = " + i);

        //postincremento
        i=2;
        j=i++;
        System.out.println("j = " + j);
        System.out.println("i = " + i);

        //predecremento
        i = 3;
        j= --i;
        System.out.println("j = " + j);
        System.out.println("i = " + i);

        //postdecremento
        i=4;
        j = i--;
        System.out.println("j = " + j);
        System.out.println("i = " + i);

        System.out.println("(++j) = " + (++j));
        System.out.println("(--j) = " + (j++));
        System.out.println("(++i) = " + (i++));
        System.out.println("(--i) = " + (i--));
        System.out.println("j = " + j);
        System.out.println("i = " + i);


    }
}
