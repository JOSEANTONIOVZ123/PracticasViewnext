package Operadores;

import java.util.Scanner;

public class EstanqueGasolina {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese la capacidad del tanque de gasolina");
        double gasolina = scanner.nextDouble();

        if (gasolina == 70) {
            System.out.println("Estanque lleno");
        } else if (gasolina >60 && gasolina <70) {
            System.out.println("Estanque casi lleno");
        } else if (gasolina >40 && gasolina<60) {
            System.out.println("Estanque 3/4");
        } else if (gasolina >35 && gasolina<40) {
            System.out.println("Medio Estanque");
        } else if (gasolina >20 && gasolina<35) {
            System.out.println("Suficiente");
        }else {
            System.out.println("Insuficiente");
        }
    }
}
