package Operadores;

import javax.swing.*;

public class OperadorAritmetico {
    public static void main(String[] args) {

        int i = 5; int j = 4; int suma = i+j;

        System.out.println("suma = " + suma);

        System.out.println("(i+j) = " + (i+j));
        
        int resta = i-j;
        System.out.println("resta = " + resta);

        System.out.println("(i-j = " + (i-j));
        
        int multiplicacion = i*j;
        System.out.println("multiplicacion = " + multiplicacion);
        
        int division = i/j;
        float div2 = (float)i/j;
        System.out.println("division = " + division);
        System.out.println("div2 = " + div2);
        
        int resto = i % j;
        System.out.println("resto = " + resto);

        resto = 8%5;
        System.out.println("resto = " + resto);

        int numero = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero"));
        if (numero%2==0){
            System.out.println("numero par = " + numero);
        }else {
            System.out.println("numero impar = " + numero);
        }
    }
}
