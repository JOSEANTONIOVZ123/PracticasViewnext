package Operadores;

import java.util.Scanner;

public class MostrarOrdenadosDosNumeros {
    public static void main(String[] args) {
        int num1 = 0;
        int num2 = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el primer numero");
         num1 =  scanner.nextInt();
        System.out.println("Ingrese el segundo numero");
        num2 = scanner.nextInt();

        int mayor;
        int menor;
        mayor=num2>num1? num2: num1;
        menor=num1<num2? num1: num2;
        System.out.println("El numero mayor es " + mayor);
        System.out.println("el numero menor es = " + menor);

    }
}
