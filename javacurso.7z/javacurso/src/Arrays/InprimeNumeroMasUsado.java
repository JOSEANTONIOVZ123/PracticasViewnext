package Arrays;

import java.util.Scanner;

public class InprimeNumeroMasUsado {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int[] numeros= new int[7];
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Ingrese un numero");
            numeros[i]=s.nextInt();
        }
        int[] arregloCantidadValores = new int[10];

        for (int i = 0; i < numeros.length; i++) {
            int contador=0;
            for (int j = 0; j < numeros.length; j++) {
                if (numeros[i]==numeros[j]){
                    contador++;
                }
                arregloCantidadValores[i]=contador;
            }
        }
        int max=0;
        int indice=0;
        for (int i = 0; i < numeros.length; i++) {
            if (max<arregloCantidadValores[i]) {
                max=arregloCantidadValores[i];
                indice=i;
            }
        }
        System.out.println("La mayor ocurrencia es " + max);
        System.out.println("El elemento que mas se repite es " + numeros[indice]);
        System.out.println("el elemento "+numeros[indice]+ " esta repetido " + max + " veces");




    }
}
