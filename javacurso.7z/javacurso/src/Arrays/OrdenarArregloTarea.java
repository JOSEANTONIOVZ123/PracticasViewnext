package Arrays;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Scanner;

public class OrdenarArregloTarea {
    public static void main(String[] args) {

        int[] arreglo = new int[10];
        int[] num = new int[10];
        Scanner s = new Scanner(System.in);
        System.out.println("Escribe 10 numeros");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("Escibe un numero: ");
            arreglo[i] = s.nextInt();
        }

        int subir =0;
        for (int i = 0; i < arreglo.length -i ; i++) {
            num[subir++] =arreglo[i];
            num[subir++] =arreglo[arreglo.length-1-i];
        }
        for (int i = 0; i < num.length; i++) {
            System.out.println("i = "+i+" valor :" + num[i]);

        }


    }

}
