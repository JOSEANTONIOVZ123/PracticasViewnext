package Arrays;

import java.util.Scanner;

public class SistemaEstadisticoArreglo {
    public static void main(String[] args) {


        int[] numeros= new int[7];
        int notas =0;
        int[] promediop=new int[7];
        int[] promedion=new int[7];
        int contadorp=0;
        int contadorn=0;
        int contador0=0;
        int sumap=0;
        int suman=0;
        int totalp=0;
        int totaln=0;
        Scanner s = new Scanner(System.in);
        System.out.println("Introduce 7 numeros ");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Escribe el  numero"+ i);
            notas=s.nextInt();
            for (int j = 0; j <1 ; j++) {
                if (notas >0) {
                    promediop[i]=notas;
                    sumap=sumap+promediop[i];
                    contadorp++;
                    System.out.println("p :"+promediop[j]);
                }
                if (notas <0) {
                    promedion[i]=notas;
                    suman=suman+promedion[i];
                    contadorn++;
                    System.out.println("n : "+ promedion[i]);
                }
                if (notas == 0){
                    contador0++;
                    System.out.println(contador0);
                }
            }

        }
        if (sumap>0) {
            totalp = sumap / contadorp;
        }
        if (suman>0) {
            totaln = suman / contadorn;
        }
        System.out.println("Hay "+totalp+" media positivos , "+totaln+" media negativos y "+contador0+" contador de 0");

    }
}
