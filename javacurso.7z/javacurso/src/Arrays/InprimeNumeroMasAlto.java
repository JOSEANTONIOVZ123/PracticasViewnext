package Arrays;

import java.util.Scanner;

public class InprimeNumeroMasAlto {
    public static void main(String[] args) {


        int[] numeros= new int[7];
        int filtro=0;
        int max = 0;
        Scanner s = new Scanner(System.in);
        System.out.println("Introduce 7 numeros entre 11 y 99");
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[0] == 0) {
                i=0;
            }
            System.out.println("Escribe el  numero");
            filtro=s.nextInt();
            if (filtro>10 && filtro <99) {
                numeros[i]=filtro;
                max=max<numeros[i]? max=numeros[i]:max;
            }else{
                System.out.println("debe ser entre 11 y 99");
                i=i-1;
            }
            if (i == -1) {
                i=0;
            }
        }
        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros[i]);
        }
        System.out.println("El numero maximo es : "+ max);

    }
}
