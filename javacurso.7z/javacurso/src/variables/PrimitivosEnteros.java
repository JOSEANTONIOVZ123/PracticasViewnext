package variables;

public class PrimitivosEnteros {
    public static void main(String[] args) {
        
        byte numeroByte = 127;
        System.out.println("numeroByte = " + numeroByte);
        System.out.println("tipo byte corresponde en byte a"+Byte.BYTES);
        System.out.println("tipo byte corresponde en byte a"+Byte.SIZE);
        System.out.println("Valor máximo del Byte"+Byte.MAX_VALUE);
        System.out.println("Valor minimo del Byte"+Byte.MIN_VALUE);

        short numeroShort = 32767;
        System.out.println("numeroShort = " + numeroShort);
        System.out.println("tipo byte corresponde en short a "+Short.BYTES);
        System.out.println("tipo byte corresponde en Short a "+Short.SIZE);
        System.out.println("Valor máximo del Short "+Short.MAX_VALUE);
        System.out.println("Valor minimo del Short "+Short.MIN_VALUE);

        int numeroInt = 2147483647;
        System.out.println("numeroInt = " + numeroInt);
        System.out.println("tipo int corresponde en byte a "+Integer.BYTES);
        System.out.println("tipo int corresponde en bites a "+Integer.SIZE);
        System.out.println("valor maximo de un int: "+Integer.MAX_VALUE);
        System.out.println("valor minimo de un int: "+Integer.MIN_VALUE);

        long numeroLong = 9223372036854775807L;
        System.out.println("numeroLong = " + numeroLong);
        System.out.println("tipo long corresponde en long a "+Long.BYTES);
        System.out.println("tipo long corresponde en bites a "+Long.SIZE);
        System.out.println("valor minimo de un long: "+Long.MIN_VALUE);

        double numeroDouble = 9223372036854775807.0;
        System.out.println("numeroDouble = " + numeroDouble);
        System.out.println("tipo double corresponde en double a "+Double.BYTES);
        System.out.println("tipo double corresponde en bites a "+Double.SIZE);
        System.out.println("valor minimo de un double: "+Double.MIN_VALUE);
        System.out.println("Valor maximo de un double: " + Double.MAX_VALUE);

        float numeroFloat = 9223372036854775807.0f;
        System.out.println("numeroFloat = " + numeroFloat);
        System.out.println("tipo float corresponde en float a "+Float.BYTES);
        System.out.println("tipo float corresponde en bites a "+Float.SIZE);
        System.out.println("valor minimo de un float: "+Float.MIN_VALUE);
        System.out.println("Valor maximo de un float: "+Float.MAX_VALUE);



    }
}
