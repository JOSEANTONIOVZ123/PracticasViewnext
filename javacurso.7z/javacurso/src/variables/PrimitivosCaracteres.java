package variables;

public class PrimitivosCaracteres {
    public static void main(String[] args) {
        var caracter = '\u0040';
        var decimal = 64;
        System.out.println("Caracter = " + caracter);
        System.out.println("Decimal = " + decimal);
        System.out.println("decimal = caracter: " + (decimal == caracter));

        char simbolo = '@';
        System.out.println("Simbolo = " + simbolo);
        System.out.println("simbolo = caracter: " + (simbolo == caracter));
        char espacio = '\u0020';
        char retroceso = '\b';
        char tabulador = '\t';
        char nuevaLinea = '\n';
        char retornoCarro = '\r';
        System.out.println("Char corresponde en byte=" +System.lineSeparator()+ Character.BYTES);
        System.out.println("Char corresponde en bites = " + Character.SIZE);
        System.out.println("Char min = " + Character.MIN_VALUE);
        System.out.println("Char max= " + Character.MAX_VALUE);



    }
}
