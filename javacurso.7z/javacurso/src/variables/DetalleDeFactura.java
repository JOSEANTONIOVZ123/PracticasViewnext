package variables;

import java.util.Scanner;

public class DetalleDeFactura {
    public static void main(String[] args) {

        Scanner scanner =new Scanner(System.in);

        System.out.println("Escribeme el nombre de la factura con espacios");
        String factura = scanner.next();

        System.out.println("Escribe el precio del primer producto");
        double producto1 = scanner.nextDouble();

        System.out.println("Escribe el precio del segundo producto");
        double producto2 = scanner.nextDouble();

        double suma= producto1+producto2;
        double iva = (suma*19)/100;
        double totalP=suma+iva;



        String resultado = "La factura " + factura +
                " tiene un total bruto de " +suma+", con un impuesto de "
                +iva+ " y el monto después del impuesto es de "+totalP;

        System.out.println(resultado);
    }
}
