package variables;

public class PrimitivosFloat {
    //static float varFlotante = 45.45f;

    public static void main(String[] args) {

        float realFloat = 0.00000000015f;//1.5e-10f;
        System.out.println("realFloat = " + realFloat);
        System.out.println("float correspondiente en byte a: " + Float.BYTES);
        System.out.println("float correspondiente en byte a: " + Float.SIZE);
        System.out.println("float max en byte a: " + Float.MAX_VALUE);
        System.out.println("float min en byte a: " + Float.MIN_VALUE);


        double realDouble = 3.4028235E38;
        System.out.println("realDouble = " + realDouble);
        System.out.println("double correspondiente en byte a: " + Double.BYTES);
        System.out.println("double correspondiente en byte a: " + Double.SIZE);
        System.out.println("double max en byte a: " + Double.MAX_VALUE);
        System.out.println("double min en byte a: " + Double.MIN_VALUE);

       float varFlotante=3.1416f;
        System.out.println("varFlotante = " + varFlotante);
    }
}
