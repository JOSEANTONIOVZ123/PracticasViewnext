package variables;


import java.util.Locale;

public class HolaMundo {

    public static void main(String[] args) {
        String saludar = "Hola Mundo desde Java ";
        System.out.println(saludar);
        System.out.println("saludar.toUpperCase() = " + saludar.toUpperCase());
        int numero = 11;
        int numero2 = 5;
        boolean valor = true;
        if(valor){
            System.out.println("numero = " + numero);
            numero2=11;
        }

        System.out.println("numero2 = " + numero2);

        var numero3 = "15";

        String nombre;
        nombre = "Andrés";

        if(numero >10){
            nombre="juan";
        }
        System.out.println("nombre = " + nombre);
        int edadPersona = 5;
        //hola;
        /*
        hola mundo
        */;


    }

}
