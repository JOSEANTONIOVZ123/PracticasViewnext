package FlujosDeControl;

import java.util.Locale;
import java.util.Scanner;

public class SentenciaForArreglo {
    public static void main(String[] args) {
        int cont = 0;
        Scanner s = new Scanner(System.in);
        System.out.println("Escribe un nombre");
        String nombre = s.nextLine();
        String[] nombres = {
                "Andres","pepe","Maria","Paco","Lalo","Bea","Pato","Pepa"
        };
        int count = nombres.length;
        for (int i = 0; i < count; i++) {
            if (nombres[i].toLowerCase().contains(nombre)) {
                System.out.println(i+".-"+nombres[i]);
                cont++;
            }

        }
        if (cont == 0) {
            System.out.println("No hay ningun nombre con ese valor");
        }

    }
}
