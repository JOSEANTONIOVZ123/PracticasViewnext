package FlujosDeControl;

import java.util.Scanner;

public class SentenciaIfElse {
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        System.out.println("Escribe tu nota");
        float expresion = s.nextFloat();
        if (expresion >=6.5){
            System.out.println("Felicitaciones, excelente promedio");
        }else if (expresion >= 6.0){
            System.out.println("Muy buen promedio");
        }else if (expresion >= 5.5) {
            System.out.println("buen promedio");
        } else if (expresion >= 5.0) {
            System.out.println("Regular, necesitas esforzarte un poco mas");
        }else {
            System.out.println("Muy mal Has suspendido");
        }
        System.out.println("Tu promedio es: " + expresion);
    }
}
