package FlujosDeControl;

import java.util.Scanner;

public class CalcularNumeroMenorMultiplesValores {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int i = 1;
        int min=9999999;

        for  (i = 1; i <= 10; i++) {

            System.out.println("Escribe el numero"+i);
            int num = s.nextInt();
            if (num < min) {
                min = num;
            }else {
                continue;
            }
        }
        if (min < 10) {
            System.out.println("El numero menor es menor que 10 = " + min);
        }else {
            System.out.println("El numero menor es igual o mayor que 10!: ".concat(String.valueOf(min)));
        }

    }
}
