package FlujosDeControl;

import java.util.Scanner;

public class SentenciaSwitchNumDiasMes {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Ingresa el mes del año");
        int mes = s.nextInt();
        int numeroDias = 0;
        System.out.println("Ingrese el año ");
        int anho = s.nextInt();
        boolean anhoBisiesto = false;
        anhoBisiesto = (anho % 400 == 0 || (anho % 4 == 0 && anho % 100 != 0))? true : false;


        switch (mes){
            case 1,3,5,7,8,10,12:
                numeroDias=31;
                break;
            case 4,6,9,11:
                numeroDias=30;
            case 2:
                if(anhoBisiesto){
                    numeroDias=29;
                }else numeroDias=28;
                break;
            default:
                System.out.println("no es un mes");
        }
        /*
        if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
            numeroDias = 31;
            System.out.println("31 dias");
        } else if (mes == 4 || mes ==6 || mes == 9 || mes == 11) {
            numeroDias = 30;
        } else if (mes == 2) {
            numeroDias = 28;
            if (anhoBisiesto) {
                numeroDias = 29;
            }
        }
        */

        System.out.println("Es el mes ".concat(String.valueOf(mes)).concat("del año: ").concat(String.valueOf(anho)).concat(" los cuales contienen: ").concat(String.valueOf(numeroDias)));
    }
}
