package FlujosDeControl;

public class SentenciaFor {
    public static void main(String[] args) {

        for (int i = 10; i>=1; i--){
            if (i%2==0){
                System.out.println("i = " + i);
            }else {

            continue;

            }
        }
        for (int j=1; j<=10; j++){
            boolean b = !(j % 2 == 0);
            if (b) {

                System.out.println("j = " + j);

            }else{
                continue;
            }
        }
    }
}
