package FlujosDeControl;

import java.util.Scanner;

public class SistemaNotasAlumnos {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int contadorApto=0;
        int contadorSusp=0;
        int cont0=0;
        double sum4=0;
        double sum5=0;
        double nota = -1;
        for (int i = 1; i <=20; i++) {
            while (nota>7 || nota < 0 ) {
                System.out.println("Escriba la nota ".concat(String.valueOf(i)));
                nota = sc.nextDouble();
            }
            if (nota >5){
                contadorApto++;
                sum5 += nota;
            }else if (nota<4 && nota >0.1){
                contadorSusp++;
                sum4 += nota;
            } else if (nota == 0) {
                System.out.println("Ha habido un error, Apagando la maquina");
                cont0=1;
                break;

            }
            nota=-1;
        }

        if (cont0!=1){
            System.out.println("Hay "+contadorApto + " aprobados y la media es : "+(sum5/20));
            System.out.println("Hay "+contadorSusp + " suspensos y la media es : "+(sum4/20));

        }




    }
}
