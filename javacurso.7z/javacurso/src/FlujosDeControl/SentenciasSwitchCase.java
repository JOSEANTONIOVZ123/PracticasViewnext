package FlujosDeControl;

import java.util.Scanner;

public class SentenciasSwitchCase {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int mes = s.nextInt();
        System.out.println("Escribe el mes en numero");
        String nombreMes = null;
        switch (mes) {
            case 1: nombreMes = "Enero";
            break;
            case 2: nombreMes = "Febrero";
            break;
            case 3: nombreMes = "Marzo";
            break;
            case 4: nombreMes = "Abril";
            break;
            case 5: nombreMes = "Mayo";
            break;
            case 6: nombreMes = "Junio";
            break;
            case 7: nombreMes = "Julio";
            break;
            case 8: nombreMes = "Agosto";
            break;
            case 9: nombreMes = "Septiembre";
            break;
            case 10: nombreMes = "Octubre";
            break;
            case 11: nombreMes = "Noviembre";
            break;
            case 12: nombreMes = "Diciembre";
            break;
            default: nombreMes = "nombre de mes desconocido";
        }
            char num = 'z';


            switch (num) {
                case 0:
                    System.out.println("El num es 0");
                    break;
                case 1:
                    System.out.println("El num es 1");
                    break;
                case 2:
                    System.out.println("El num es 2");
                    break;
                case 3:
                    System.out.println("El num es 3");
                    break;
                default:
                    System.out.println("hola");
            }
        System.out.println("El mes es: " + nombreMes);
        }
    }

