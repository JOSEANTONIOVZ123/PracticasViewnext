package FlujosDeControl;

import java.util.Scanner;

public class MultiplicarNumeros {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Escribame un numero");
        int num1 = sc.nextInt();
        if(num1 <0){
            num1=-num1;
        }
        System.out.println("Escribame otro numero");
        int num2 = sc.nextInt();
        if(num2 <0){
            num2=-num2;
        }
        int inicial=num1;
        System.out.println(inicial+" por "+(1)+" : "+num1);
        for (int i = 1; i <num2; i++) {
            num1+=inicial;
            System.out.println(inicial+" por "+(i+1)+" : "+num1);
        }
    }
}
