let contadorFallos = 0;
let contador = 0;
const palabras = ["casa","perro","maestro","codigo","carro"];//array de las palabras del juego

const palabra = palabras[Math.floor(Math.random() * palabras.length)]; //funcion matematica para preparar una palabra random;

console.log(palabra)
let palabraConGuiones = palabra.replace(/./g, "_ "); // reemplazar las palabras por guion /g es global.

id("output").innerHTML = palabraConGuiones; // imprime palabra con guiones en un <p>.

const button = id("calcular");
button.addEventListener("click",jugar);

function jugar(){

    let letra = id("letra").value;     // obtener el valor de la letra ingresada en la id de letra y guardarlo en la const letra.
    letra = letra.toLowerCase();       // convertir la letra en minuscula. 
        let haAcertado=false;
        for (const i in palabra){

            if (letra === palabra[i]) {
             palabraConGuiones =reemplazar(palabraConGuiones,i*2,letra);
             haAcertado=true;
            // reemplazar los datos de id output por la variable palabra con guiones.
            id("output").innerHTML = palabraConGuiones;
            }
        }


            if (haAcertado==false) {
                contador++;
                const source =`./gancho${contador}.png`;
                const imagen = document.querySelector( '#ahorcado');
                imagen.src = source;

                if (contador>6) {
                    msjPerdido();
                    button.disabled = true;
                }
            }else {
                
                if (palabraConGuiones.indexOf("_ ") < 0){
                msjGano();
                button.disabled = true;
            }
            }   
 }

function reemplazar(palabra, index, character){
    return (
        palabra.substring(0, index) +               //elimina los "_ " hasta donde se encontro el index.
        character +                                 // Ingresa la letra que se escribió.
        palabra.substring(index + character.length) //rellena el resto de "_"
    );




};


function msjPerdido(){
id("resultado").innerHTML = "Perdiste, te han colgado";
id("resultado").style.backgroundColor = "#740707";
}

function msjGano(){
    id("resultado").innerHTML = "¡¡HAS GANADO!!";
    id("resultado").style.backgroundColor = "#0c5a7";
    }
    function moveImg(){
        id("ahorcado").style.backgroundColor ="px 0px";
        id("ahorcado").style.opacity =1.0;
    }

    
    function id(variable){
        return document.getElementById(variable);
    }
